Lemon/Milk.otf ver 2.1 (donationware)

Fortunately, in this version, major European accents have been added, and I also modified some characters such as "D", "J", "&", and the dot. 
Furthermore, the kerning issue like when "A" meets "V" has been fixed.

However,As I've received some infringement reports and I've seen some nationwide companies using Lemon/Milk commercially without permission,
unfortunatelly, I have to update the agreement of use:
Please email to marsnev@marsnev.com before use it on commercial purpose.
Just feel free to use as long as it is personal use (such as for sticker, t-shirt, or design which you don't sell), non-profit use (such as for environmental-campaign poster you did), or social-fundraising use (such as for t-shirt you sell which profits will be donated for those in need)
And this font is also absolutely prohibited to be used in bad things which are against any law, religion, or other rules (such as supporting drugs use, and illegal products)

every donation is highly appreciated.
facebook.com/marsneveneksk
twitter.com/MARSNEV
instagram.com/MARSNEV

email address: marsnev@marsnev.com

paypal address: callmetwentynine@gmail.com

Thanks for being suportive,
MARSNEV
Jakarta, Indonesia